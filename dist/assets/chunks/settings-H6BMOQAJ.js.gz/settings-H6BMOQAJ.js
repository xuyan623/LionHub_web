import {
  renderFileManagerModal
} from "./chunk-FQRIJ6CW.js";
import "./chunk-OANHKQRB.js";
import "./chunk-VDLKH6VR.js";
import "./chunk-VXIKIDMW.js";
import "./chunk-UKTXZA3P.js";
import "./chunk-SXRKLTAB.js";
import "./chunk-UQLSNBUY.js";
import "./chunk-GV2AYCPY.js";
import "./chunk-5IOWRUG7.js";

// client/render/modal-groups/settings.js
function render(modalType) {
  if (modalType === "file-manager") {
    return renderFileManagerModal();
  }
  return "";
}
export {
  render
};
